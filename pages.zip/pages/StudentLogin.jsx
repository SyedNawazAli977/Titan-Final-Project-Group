import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import '../styles/login.css';
import logo from "../assets/logo.jpeg";

const StudentLogin = () => {
  const [portal, setPortal] = useState('student'); 
  const [activeTab, setActiveTab] = useState('login'); 
  const [showPassword, setShowPassword] = useState(false); 
  const navigate = useNavigate();

  const togglePasswordVisibility = () => {
    setShowPassword(!showPassword);
  };

  return (
    <div className="login-page">
      
      <div className="login-header">
    
     <img src={logo} alt="Titan Logo" className="Titan-logo"   style={{ width: "160px", height: "auto" }}/>
        <h2 className="portal-title">
          {portal === 'student' ? 'Student Portal' : 'Trainer Portal'}
        </h2>
      </div>

    
      {portal === 'student' && (
        <div className="tabs-container">
          <button
            className={`tab-btn ${activeTab === 'login' ? 'active' : ''}`}
            onClick={() => setActiveTab('login')}
          >
            Login
          </button>
          <button
            className={`tab-btn ${activeTab === 'createPassword' ? 'active' : ''}`}
            onClick={() => setActiveTab('createPassword')}
          >
            Create Password
          </button>
        </div>
      )}

      
      <div className="login-card">
   
        {portal === 'teacher' ? (
          <div className="form-content">
            <h3>Login</h3>
            <p className="form-desc">Kindly provide your email and password to access the trainer portal.</p>

            <div className="input-group">
              <label>Email *</label>
              <input type="email" placeholder='Enter Email'  />
            </div>

            <div className="input-group">
              <label>Password *</label>
              <div className="password-wrapper">
                <input type={showPassword ? "text" : "password"} placeholder="••••••••" />
                <span className="eye-icon" onClick={togglePasswordVisibility} style={{ cursor: 'pointer' }}>
                  {showPassword ? "👁️‍🗨️" : "👁️"}
                </span>
              </div>
            </div>

            <p className="forgot-password" style={{ color: '#2b3990', textAlign: 'center', cursor: 'pointer', fontSize: '13px', margin: '15px 0' }}>
              Forgot Password?
            </p>

            <button className="submit-btn" onClick={() => navigate('/dashboard')}>LOGIN</button>
          </div>
        ) : (
         
          activeTab === 'login' ? (
            <div className="form-content">
              <h3>Login</h3>
              <p className="form-desc">Kindly provide the CNIC number and password used during Titan course registration.</p>

              <div className="input-group">
                <label>CNIC *</label>
                <input type="text" placeholder="Enter CNIC" />
              </div>

              <div className="input-group">
                <label>Password *</label>
                <div className="password-wrapper">
                  <input type={showPassword ? "text" : "password"} placeholder="••••••••" />
                  <span className="eye-icon" onClick={togglePasswordVisibility} style={{ cursor: 'pointer' }}>
                    {showPassword ? "👁️‍🗨️" : "👁️"}
                  </span>
                </div>
              </div>

              <button className="submit-btn" onClick={() => navigate('/dashboard')}>LOGIN</button>
            </div>
          ) : (
            <div className="form-content">
              <h3>Create a Password</h3>
              <p className="form-desc">Kindly provide the CNIC number and DOB used during Titan course registration.</p>

              <div className="input-group">
                <label>CNIC *</label>
                <input type="text" placeholder="Enter CNIC" />
              </div>

              <div className="input-group">
                <label>DOB *</label>
                <input type="date" />
              </div>

              <div className="input-group">
                <label>Password *</label>
                <div className="password-wrapper">
                  <input type={showPassword ? "text" : "password"} placeholder="••••••••" />
                  <span className="eye-icon" onClick={togglePasswordVisibility} style={{ cursor: 'pointer' }}>
                    {showPassword ? "👁️‍🗨️" : "👁️"}
                  </span>
                </div>
              </div>

              <button className="submit-btn">SUBMIT</button>
            </div>
          )
        )}
      </div>

      {/* Switch Portal Button (Bottom) */}
      {portal === 'student' ? (
        <button className="switch-portal-btn" onClick={() => setPortal('teacher')}>
          Login as teacher
        </button>
      ) : (
        <button className="switch-portal-btn" onClick={() => setPortal('student')}>
          Login as student
        </button>
      )}
    </div>
  );
};

export default StudentLogin;