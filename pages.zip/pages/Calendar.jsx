import Sidebar from "../components/Sidebar";
import Calendar from "../components/Calendar";
import "../styles/calendar.css";

export default function CalendarPage(){

const days=[
"Sun","Mon","Tue","Wed","Thu","Fri","Sat"
];

return(

<div className="layout">

<Sidebar/>

<div className="content">

<h1>Calendar</h1>

<div className="calendar">

{
days.map((day)=>(
<div className="day">

<h3>{day}</h3>

<div className="event">
Modern Web App
</div>

</div>
))
}

</div>

</div>

</div>

)

}