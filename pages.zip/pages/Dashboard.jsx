import React from 'react';
import Sidebar from '../components/Sidebar';
import "../styles/Dashboard.css";

const Dashboard = () => {
  // Mock Cards Data (Jo image me cards hain)
  const activeCourses = [
    {
      title: "Little Geniuses: Coding, Design & AI Fun Lab",
      gender: "LAB | Male",
      campus: "SMIT Ghotki Campus (Ghotki)",
      batch: "Batch 1",
      students: "4 students",
      schedule: "Sat 04:00 PM - 06:00 PM | Sun 04:00 PM - 06:00 PM",
      started: "1 Jun 2026",
      progress: 0,
      themeClass: "card-green"
    },
    {
      title: "Little Geniuses: Coding, Design & AI Fun Lab",
      gender: "LAB | Female",
      campus: "SMIT Ghotki Campus (Ghotki)",
      batch: "Batch 1",
      students: "8 students",
      schedule: "Sat 12:00 PM - 02:00 PM | Sun 12:00 PM - 02:00 PM",
      started: "1 Jun 2026",
      progress: 0,
      themeClass: "card-blue"
    },
    {
      title: "Modern Web Application Development",
      gender: "LAB | Female",
      campus: "SMIT Ghotki Campus (Ghotki)",
      batch: "Batch 3",
      students: "30 students",
      schedule: "Sat 08:00 AM - 10:00 AM | Sun 08:00 AM - 10:00 AM",
      started: "1 Jan 2026",
      progress: 25,
      themeClass: "card-red"
    }
  ];

  return (
    <div className="dashboard-layout">
      <Sidebar />
      
      <div className="dashboard-main">
        <h1 className="page-title">Dashboard</h1>

        {/* Top Stats Cards */}
        <div className="stats-row">
          <div className="stat-card">
            <div className="stat-info">
              <h2>6</h2>
              <p>Active Courses</p>
            </div>
            <span className="stat-icon icon-green">📖</span>
          </div>
          <div className="stat-card">
            <div className="stat-info">
              <h2>102</h2>
              <p>Enrolled Students</p>
            </div>
            <span className="stat-icon icon-blue">👤</span>
          </div>
          <div className="stat-card">
            <div className="stat-info">
              <h2>0</h2>
              <p>Total Assignments</p>
            </div>
            <span className="stat-icon icon-purple">📝</span>
          </div>
        </div>

        {/* Section Heading */}
        <h2 className="section-title">Active Courses</h2>

        {/* Courses Grid */}
        <div className="courses-grid">
          {activeCourses.map((course, idx) => (
            <div key={idx} className={`course-card ${course.themeClass}`}>
              <div className="card-top-header">
                <h3>{course.title}</h3>
                <span className="batch-tag">{course.batch}</span>
              </div>
              <p className="meta-text">{course.gender}</p>
              <p className="campus-text">{course.campus}</p>
              
              <div className="progress-section">
                <div className="progress-label">
                  <span>Progress</span>
                  <span>{course.progress}% Completed</span>
                </div>
                <div className="progress-bar-bg">
                  <div className="progress-bar-fill" style={{ width: `${course.progress}%` }}></div>
                </div>
              </div>

              <div className="card-details">
                <p>👤 Enrolled : {course.students}</p>
                <p>⏰ Schedule: {course.schedule}</p>
                <p>📅 Started On: {course.started}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Dashboard;